# 設計說明：環境安裝與 AMQP 基礎

## 架構文字圖
- Producer → Exchange（主題依單元） → Queue → Consumer
- 以文字描述資料流與錯誤分流（重試、DLQ）

## 交換器與佇列設定表
| 名稱 | 類型 | 關鍵參數 | 說明 |
|---|---|---|---|
| 主交換器 | 依主題 | 持久化、備援 | 訊息進入點 |
| 主佇列 | 任務 | durable、TTL、DLX | 主要工作佇列 |
| 重試佇列 | 任務 | 延遲策略 | 失敗重試緩衝 |
| DLQ | 任務 | parking-lot | 最終處置 |

## 訊息流程
1. 收到訊息並進入主佇列
2. Consumer 處理，成功則 ACK
3. 失敗則依策略退避或導至 DLQ
4. 管理端檢視指標並人工處置

## 錯誤處理策略
- 可預期錯誤：重試與退避
- 不可預期錯誤：直接送往 DLQ
- 冪等與去重：以業務鍵避免重複

## 可靠性語意
- at-least-once 透過手動 ACK 與重試達成
- exactly-once 以冪等與外部一致性補強
- at-most-once 僅適用低風險通知類

## 主題特化重點
- AMQP 基本模型：Producer、Exchange、Queue、Consumer
- Virtual host 隔離與權限模型
- 管理介面導覽與健康檢查

## 參數建議值
- prefetch：依處理時間與併發調整
- TTL：依業務有效期設定
- 重試上限：限制風暴並保留 DLQ 觀測
