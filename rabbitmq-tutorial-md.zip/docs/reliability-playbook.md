# 可靠性作戰手冊
- 連線中斷：重連策略與退避
- 訊息重送：冪等消費與去重鍵
- 重試上限：parking-lot 處置流程
- 雙寫一致性：Transactional Outbox
- 高可用：Quorum Queue 與節點容錯
